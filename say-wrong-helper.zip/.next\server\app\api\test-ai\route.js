var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/test-ai/route.js")
R.c("server/chunks/[root-of-the-server]__dec4a5ea._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_test-ai_route_actions_8271e867.js")
R.m(32618)
module.exports=R.m(32618).exports
