module.exports=[12849,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_test-prompt_page_actions_e27e33fd.js.map