var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/generate/route.js")
R.c("server/chunks/[root-of-the-server]__73c9efb1._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_generate_route_actions_5bfe9259.js")
R.m(6713)
module.exports=R.m(6713).exports
