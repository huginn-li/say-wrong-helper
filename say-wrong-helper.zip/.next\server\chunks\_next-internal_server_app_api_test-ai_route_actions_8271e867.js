module.exports=[21807,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_test-ai_route_actions_8271e867.js.map